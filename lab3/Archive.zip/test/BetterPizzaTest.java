import org.junit.Test;
import betterpizza.AlaCartePizza;
import betterpizza.CheesePizza;
import betterpizza.ObservablePizza;
import betterpizza.VeggiePizza;
import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

import static org.junit.Assert.*;

/**
 * Additional test cases for the BetterPizza classes.
 */
public class BetterPizzaTest {

  /**
   * Tests the cost calculation of an AlaCartePizza with no toppings.
   */
  @Test
  public void testAlaCartePizzaNoToppings() {
    ObservablePizza alacarte = new AlaCartePizza.AlaCartePizzaBuilder()
            .crust(Crust.Thin)
            .size(Size.Small)
            .build();

    assertEquals("Cost should only include the base cost of a small pizza", alacarte.cost(), Size.Small.getBaseCost(), 0.001);
  }

  /**
   * Tests that an exception is thrown when no crust is provided for AlaCartePizza.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAlaCartePizzaNoCrust() {
    new AlaCartePizza.AlaCartePizzaBuilder()
            .size(Size.Large)
            .build();
  }

  /**
   * Tests that an exception is thrown when no size is provided for AlaCartePizza.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testAlaCartePizzaNoSize() {
    new AlaCartePizza.AlaCartePizzaBuilder()
            .crust(Crust.Classic)
            .build();
  }

  /**
   * Tests adding a single topping to AlaCartePizza.
   */
  @Test
  public void testAlaCartePizzaSingleTopping() {
    ObservablePizza alacarte = new AlaCartePizza.AlaCartePizzaBuilder()
            .crust(Crust.Stuffed)
            .size(Size.Medium)
            .addTopping(ToppingName.Cheese, ToppingPortion.Full)
            .build();

    double expectedCost = Size.Medium.getBaseCost() + ToppingName.Cheese.getCost() * ToppingPortion.Full.getCostMultiplier();
    assertEquals("Cost should include base cost plus one full topping", expectedCost, alacarte.cost(), 0.001);
  }

  /**
   * Tests that an exception is thrown when no crust is provided for CheesePizza.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCheesePizzaNoCrust() {
    new CheesePizza.CheesePizzaBuilder()
            .size(Size.Medium)
            .build();
  }

  /**
   * Tests that an exception is thrown when no size is provided for CheesePizza.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testCheesePizzaNoSize() {
    new CheesePizza.CheesePizzaBuilder()
            .crust(Crust.Thin)
            .build();
  }

  /**
   * Tests the basic cost of a CheesePizza.
   */
  @Test
  public void testCheesePizzaBasicCost() {
    CheesePizza cheesePizza = new CheesePizza.CheesePizzaBuilder()
            .crust(Crust.Classic)
            .size(Size.Large)
            .build();

    assertEquals("Cheese pizza should only have base cost", Size.Large.getBaseCost(), cheesePizza.cost(), 0.001);
  }

  /**
   * Tests the cost calculation of a VeggiePizza.
   */
  @Test
  public void testVeggiePizzaBasicCost() {
    VeggiePizza veggiePizza = new VeggiePizza.VeggiePizzaBuilder()
            .crust(Crust.Stuffed)
            .size(Size.Small)
            .build();

    assertEquals("Veggie pizza should only have base cost", Size.Small.getBaseCost(), veggiePizza.cost(), 0.001);
  }

  /**
   * Tests that an exception is thrown when no crust is provided for VeggiePizza.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testVeggiePizzaNoCrust() {
    new VeggiePizza.VeggiePizzaBuilder()
            .size(Size.Medium)
            .build();
  }

  /**
   * Tests that an exception is thrown when no size is provided for VeggiePizza.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testVeggiePizzaNoSize() {
    new VeggiePizza.VeggiePizzaBuilder()
            .crust(Crust.Classic)
            .build();
  }

  /**
   * Tests adding multiple toppings to an AlaCartePizza and calculates the cost.
   */
  @Test
  public void testAlaCartePizzaMultipleToppings() {
    ObservablePizza alacarte = new AlaCartePizza.AlaCartePizzaBuilder()
            .crust(Crust.Classic)
            .size(Size.Large)
            .addTopping(ToppingName.Cheese, ToppingPortion.Full)
            .addTopping(ToppingName.Onion, ToppingPortion.Full)
            .addTopping(ToppingName.GreenPepper, ToppingPortion.LeftHalf)
            .build();

    double expectedCost = Size.Large.getBaseCost()
            + ToppingName.Cheese.getCost() * ToppingPortion.Full.getCostMultiplier()
            + ToppingName.Onion.getCost() * ToppingPortion.Full.getCostMultiplier()
            + ToppingName.GreenPepper.getCost() * ToppingPortion.LeftHalf.getCostMultiplier();

    assertEquals("Cost should include base cost and multiple toppings", expectedCost, alacarte.cost(), 0.001);
  }

  /**
   * Tests the hasTopping method for an AlaCartePizza with a topping.
   */
  @Test
  public void testAlaCartePizzaHasTopping() {
    ObservablePizza alacarte = new AlaCartePizza.AlaCartePizzaBuilder()
            .crust(Crust.Classic)
            .size(Size.Medium)
            .addTopping(ToppingName.Jalapeno, ToppingPortion.Full)
            .build();

    assertNotNull("AlaCartePizza should have Mushroom topping", alacarte.hasTopping(ToppingName.Jalapeno));
  }

  /**
   * Tests the hasTopping method for a VeggiePizza (which has no additional toppings).
   */
  @Test
  public void testVeggiePizzaHasNoTopping() {
    VeggiePizza veggiePizza = new VeggiePizza.VeggiePizzaBuilder()
            .crust(Crust.Thin)
            .size(Size.Medium)
            .build();

    assertNull("VeggiePizza should have no additional toppings", veggiePizza.hasTopping(ToppingName.Onion));
  }
}
