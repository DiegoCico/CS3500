package cs3500.simon.model;

/**
 * enum with all the colors.
 */
public enum ColorGuess {
  Red,
  Yellow,
  Green,
  Blue
}
