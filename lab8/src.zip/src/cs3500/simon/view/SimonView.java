package cs3500.simon.view;

import cs3500.simon.model.ReadOnlySimon;

public interface SimonView {
  void addFeatureListener(ViewFeatures features);

  void display(boolean show);

  /**
   * Display the next color in the sequence.
   */
  void advance();

  /**
   * Tell the user that they guessed wrong.
   */
  void error();
}
