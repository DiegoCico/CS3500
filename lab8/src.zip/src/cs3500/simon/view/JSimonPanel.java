package cs3500.simon.view;


import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.Stack;

import javax.swing.*;
import javax.swing.event.MouseInputAdapter;

import cs3500.simon.model.ColorGuess;
import cs3500.simon.model.ReadOnlySimon;

/**
 * Panel for rendering and interacting with Simon game elements.
 */
class JSimonPanel extends JPanel {
  private final ReadOnlySimon model;
  private final List featuresListeners;
  private final Stack<ColorGuess> currentRoundOfColorGuesses;
  private boolean mouseIsDown;
  private ColorGuess activeColorGuess;

  private final static Map<ColorGuess, Point2D> CIRCLE_CENTERS = Map.of(
          ColorGuess.Red, new Point2D.Double(10, 0),
          ColorGuess.Yellow, new Point2D.Double(0, 10),
          ColorGuess.Green, new Point2D.Double(-10, 0),
          ColorGuess.Blue, new Point2D.Double(0, -10)
  );
  private final static Map<ColorGuess, Color> CIRCLE_COLORS = Map.of(
          ColorGuess.Red, Color.CYAN,
          ColorGuess.Blue, Color.MAGENTA,
          ColorGuess.Yellow, Color.ORANGE,
          ColorGuess.Green, Color.PINK
  );

  private final static double CIRCLE_RADIUS = 5;

  public JSimonPanel(ReadOnlySimon model) {
    this.model = Objects.requireNonNull(model);
    this.featuresListeners = new ArrayList<>();
    this.currentRoundOfColorGuesses = new Stack<>();
    this.currentRoundOfColorGuesses.addAll(this.model.getCurrentSequence());
    MouseEventsListener listener = new MouseEventsListener();
    this.addMouseListener(listener);
    this.addMouseMotionListener(listener);
  }

  @Override
  public Dimension getPreferredSize() {
    return new Dimension(350, 350);
  }

  private Dimension getPreferredLogicalSize() {
    return new Dimension(40, 40);
  }

  public void advance() {
    System.err.println("Yay!");
    this.currentRoundOfColorGuesses.pop();
    if (this.currentRoundOfColorGuesses.isEmpty()) {
      this.currentRoundOfColorGuesses.addAll(this.model.getCurrentSequence());
    }
    this.repaint();
  }

  public void error() {
    JOptionPane.showMessageDialog(this, "Incorrect sequence!", "Error", JOptionPane.ERROR_MESSAGE);
    this.currentRoundOfColorGuesses.clear();
    this.currentRoundOfColorGuesses.addAll(this.model.getCurrentSequence());
    this.repaint();
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g.create();
    g2d.transform(transformLogicalToPhysical());

    // Draw calibration pattern
    drawCalibrationPattern(g2d);

    // Draw Simon circles
    for (ColorGuess colorGuess : ColorGuess.values()) {
      boolean isActive = colorGuess == activeColorGuess;
      drawCircle(g2d, CIRCLE_COLORS.get(colorGuess), CIRCLE_CENTERS.get(colorGuess), isActive);
    }
  }

  private void drawCalibrationPattern(Graphics2D g2d) {
    // Draw red diagonal
    g2d.setColor(Color.RED);
    g2d.drawLine(-20, -20, 20, 20);

    // Draw blue diagonal
    g2d.setColor(Color.BLUE);
    g2d.drawLine(-20, 20, 20, -20);

    // Draw corner circles
    drawCircle(g2d, Color.RED, new Point2D.Double(-20, 20), false);
    drawCircle(g2d, Color.YELLOW, new Point2D.Double(20, 20), false);
    drawCircle(g2d, Color.GREEN, new Point2D.Double(-20, -20), false);
    drawCircle(g2d, Color.BLUE, new Point2D.Double(20, -20), false);
  }

  private void drawCircle(Graphics2D g2d, Color color, Point2D center, boolean filled) {
    AffineTransform oldTransform = g2d.getTransform();
    g2d.translate(center.getX(), center.getY());
    g2d.setColor(color);
    Shape circle = new Ellipse2D.Double(
            -CIRCLE_RADIUS, -CIRCLE_RADIUS, 2 * CIRCLE_RADIUS, 2 * CIRCLE_RADIUS);
    if (filled) {
      g2d.fill(circle);
    } else {
      g2d.draw(circle);
    }
    g2d.setTransform(oldTransform);
  }

  private AffineTransform transformLogicalToPhysical() {
    AffineTransform ret = new AffineTransform();
    Dimension preferred = getPreferredLogicalSize();
    ret.translate(getWidth() / 2., getHeight() / 2.);
    ret.scale(getWidth() / preferred.getWidth(), getHeight() / preferred.getHeight());
    ret.scale(1, -1);
    return ret;
  }

  private AffineTransform transformPhysicalToLogical() {
    AffineTransform ret = new AffineTransform();
    Dimension preferred = getPreferredLogicalSize();
    ret.scale(1, -1);
    ret.scale(preferred.getWidth() / getWidth(), preferred.getHeight() / getHeight());
    ret.translate(-getWidth() / 2., -getHeight() / 2.);
    return ret;
  }

  private class MouseEventsListener extends MouseInputAdapter {
    @Override
    public void mousePressed(MouseEvent e) {
      JSimonPanel.this.mouseIsDown = true;
      this.mouseDragged(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
      JSimonPanel.this.mouseIsDown = false;
      if (JSimonPanel.this.activeColorGuess != null) {
        for (ViewFeatures listener : JSimonPanel.this.featuresListeners) {
          listener.selectedColor(JSimonPanel.this.activeColorGuess);
        }
      }
      JSimonPanel.this.activeColorGuess = null;
      JSimonPanel.this.repaint();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
      Point physicalP = e.getPoint();
      Point2D logicalP = transformPhysicalToLogical().transform(physicalP, null);

      for (Map.Entry<ColorGuess, Point2D> entry : CIRCLE_CENTERS.entrySet()) {
        double distance = logicalP.distance(entry.getValue());
        if (distance <= CIRCLE_RADIUS) {
          JSimonPanel.this.activeColorGuess = entry.getKey();
          break;
        } else {
          JSimonPanel.this.activeColorGuess = null;
        }
      }
      JSimonPanel.this.repaint();
    }
  }
}