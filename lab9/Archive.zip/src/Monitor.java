/**
 * monitoring how many pills added.
 */
public class Monitor extends PillDecorator{

  private PillDecorator pillDecorator;
  int counter;

  /**
   * constructor for monitor.
   */
  public Monitor() {
    pillDecorator = new PillDecorator();
    counter = 0;
  }

  /**
   * adding the pills and counting them.
   * @param count of the pills.
   */
  public void addPill(int count) {
    super.addPill(count);
    counter += count;
  }

  /**
   * getting the counter.
   * @return the counter.
   */
  public int getCounter() {
    return counter;
  }
}
