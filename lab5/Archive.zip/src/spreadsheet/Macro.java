package spreadsheet;

public interface Macro {

  /**
   * Apply a macro on the spreadsheet.
   * @param spreadSheet spreadsheet.
   */
  void apply(SpreadSheet spreadSheet);
}
