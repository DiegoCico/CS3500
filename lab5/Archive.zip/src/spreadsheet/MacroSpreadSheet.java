package spreadsheet;

public class MacroSpreadSheet extends SparseSpreadSheet implements SpreadSheetWithMacro{

  public MacroSpreadSheet() {
    super();
  }

  /**
   * Exectutes the given SpreadSheet.
   *
   * @param macro a marcro.
   */
  @Override
  public void execute(Macro macro) {
    macro.apply(this);
  }
}
