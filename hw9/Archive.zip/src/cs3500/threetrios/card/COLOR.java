package cs3500.threetrios.card;

/**
 * Class ENUM to represent each player.
 */
public enum COLOR {
  RED, BLUE
}
