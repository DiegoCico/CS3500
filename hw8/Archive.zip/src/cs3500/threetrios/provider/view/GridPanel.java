package cs3500.threetrios.provider.view;

/**
 * A Panel that displays the grid fo a three trios game.
 */
public interface GridPanel extends Panel {

  /**
   * Refreshes this view.
   */
  void refresh();

}
