package cs3500.threetrios.provider.view;


import cs3500.threetrios.controller.ThreeTriosControllerImpl;
import cs3500.threetrios.provider.controller.ViewFeatures;
import cs3500.threetrios.provider.model.Player;


public class ViewFeaturesAdapter implements ViewFeatures {
  private final ThreeTriosControllerImpl controller;

  public ViewFeaturesAdapter(ThreeTriosControllerImpl controller) {
    this.controller = controller;
  }

  /**
   * indicates that there was an attempt to play to the grid at a specic location.
   * @param row the row that the user is trying to place a card on
   * @param col the column that the user to place a card on
   */
  @Override
  public void handleGridPlay(int row, int col) {
    try {
      controller.handleCellClick(row, col);
    } catch (IllegalArgumentException e) {
      System.out.println("Invalid move: " + e.getMessage());
    }
  }

  /**
   * indiciates that there was an attempt to select a different card.
   * @param player the player who's deck it comes form
   * @param cardIdx the index of the card in the hand
   * @throws IllegalArgumentException if player is null or Player.None;
   */
  @Override
  public void handleSelectCard(Player player, int cardIdx) {
    try {
      if (player == null || player.equals(Player.NONE)) {
        throw new IllegalArgumentException("Invalid player.");
      }
      controller.handleCardSelection(cardIdx);
    } catch (IllegalArgumentException e) {
      System.out.println("Invalid card selection: " + e.getMessage());
    }
  }
}
