package cs3500.threetrios.provider.model;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cs3500.threetrios.card.COLOR;
import cs3500.threetrios.card.CardModel;
import cs3500.threetrios.game.GameModel;
import cs3500.threetrios.player.PlayerModel;

/**
 * Represents a mutable board adaptor for the ThreeTrios game.
 */
public class ReadOnlyBoardAdapter implements ReadOnlyBoard {
  private final GameModel gameModel;

  /**
   * Constructs a ReadOnlyBoardAdapter with the given GameModel.
   *
   * @param gameModel the game model to adapt
   */
  public ReadOnlyBoardAdapter(GameModel gameModel) {
    if (gameModel == null) {
      throw new IllegalArgumentException("GameModel cannot be null");
    }
    this.gameModel = gameModel;
  }

  @Override
  public boolean isGameOver() {
    return gameModel.isGameOver();
  }

  @Override
  public Player gameWinner() {
    String winner = gameModel.getWinner();
    switch (winner) {
      case "Red Wins":
        return PlayerAdapter.toProviderPlayer((PlayerModel) gameModel.getPlayers()[0]);
      case "Blue Wins":
        return PlayerAdapter.toProviderPlayer((PlayerModel) gameModel.getPlayers()[1]);
      default:
        return null;
    }
  }

  @Override
  public Slot[][] getGrid() {
    int rows = gameModel.getGrid().getRows();
    int cols = gameModel.getGrid().getCols();
    Slot[][] grid = new Slot[rows][cols];

    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        cs3500.threetrios.card.Card card = gameModel.getCardAt(row, col);
        if (card != null) {
          cs3500.threetrios.player.Player owner = findCellOwner(row, col);
          grid[row][col] = new CardAdapter(card, (PlayerModel) owner);
        }
        else {
          grid[row][col] = null;
        }
      }
    }
    return grid;
  }


  /**
   * Finds the owner of the card at the given coordinates.
   */
  private cs3500.threetrios.player.Player findCellOwner(int row, int col) {
    for (cs3500.threetrios.player.Player player : gameModel.getPlayers()) {
      for (cs3500.threetrios.card.Card card : player.getHand()) {
        if (gameModel.getCardAt(row, col) == card) {
          return player;
        }
      }
    }
    return null;
  }


  @Override
  public int gameWidth() {
    return gameModel.getGrid().getRows();
  }

  @Override
  public int gameHeight() {
    return gameModel.getGrid().getCols();
  }

  @Override
  public Slot getCoord(int x, int y) {
    CardModel card = (CardModel) gameModel.getCardAt(x, y);
    if (card == null) {
      return null;
    }
    return new CardAdapter(card,
            (PlayerModel) gameModel.getCurrentPlayerModel());
  }

  @Override
  public Player getCellOwner(int x, int y) {
    Slot slot = getCoord(x, y);
    return slot != null ? slot.getSlotOwner() : null;
  }

  @Override
  public boolean isMoveLegal(int x, int y) {
    return gameModel.isMoveLegal(x, y);
  }

  @Override
  public int score(Player player) {
    int redCount = 0;
    int blueCount = 0;

    for (int row = 0; row < gameModel.getGrid().getRows(); row++) {
      for (int col = 0; col < gameModel.getGrid().getCols(); col++) {
        CardModel card = (CardModel) gameModel.getCardAt(row, col);
        if (card != null) {
          if (card.getColor() == cs3500.threetrios.card.COLOR.RED) {
            redCount++;
          } else if (card.getColor() == cs3500.threetrios.card.COLOR.BLUE) {
            blueCount++;
          }
        }
      }
    }

    Player redPlayer = PlayerAdapter.toProviderPlayer((PlayerModel) gameModel.getPlayers()[0]);
    Player bluePlayer = PlayerAdapter.toProviderPlayer((PlayerModel) gameModel.getPlayers()[1]);

    if (player.equals(redPlayer)) {
      return redCount;
    } else if (player.equals(bluePlayer)) {
      return blueCount;
    } else {
      throw new IllegalArgumentException("Unknown player");
    }
  }

  @Override
  public int possibleCardsFlipped(CardAdapter card, int x, int y) {
    Set<cs3500.threetrios.card.Card> flippedCards = new HashSet<>();
    gameModel.battleCards(x, y, flippedCards);
    return flippedCards.size() - 1;
  }

  @Override
  public Player curPlayer() {
    return PlayerAdapter.toProviderPlayer((PlayerModel) gameModel.getCurrentPlayer());
  }

  @Override
  public List<Slot> getHand(Player player) {
    cs3500.threetrios.player.Player modelPlayer = findModelPlayer(player);

    if (modelPlayer == null) {
      throw new IllegalArgumentException("Player not found in the game model.");
    }
    List<Slot> adaptedHand = new ArrayList<>();
    for (cs3500.threetrios.card.Card card : modelPlayer.getHand()) {
      adaptedHand.add((CardAdapter) card);
    }
    return adaptedHand;
  }


  /**
   * Finds the corresponding PlayerModel in GameModel for the given provider's Player.
   *
   * @param player the provider's Player
   * @return the corresponding PlayerModel in GameModel, or null if not found
   */
  private cs3500.threetrios.player.Player findModelPlayer(Player player) {
    COLOR color;
    if (player.playerColor() == Color.RED) {
      color = cs3500.threetrios.card.COLOR.RED;
    } else {
      color = cs3500.threetrios.card.COLOR.BLUE;
    }
    for (cs3500.threetrios.player.Player modelPlayer : gameModel.getPlayers()) {
      System.out.println("Player found: " + modelPlayer.getName());
      if (modelPlayer.getColor() == color) {
        return modelPlayer;
      }
    }
    return null;
  }

}
