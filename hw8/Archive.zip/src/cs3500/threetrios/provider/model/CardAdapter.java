package cs3500.threetrios.provider.model;

import cs3500.threetrios.card.CardModel;
import cs3500.threetrios.player.PlayerModel;

import java.awt.*;
import java.util.Map;

public class CardAdapter implements Slot {
  private final cs3500.threetrios.card.Card myCard;
  private PlayerModel myPlayer;

  public CardAdapter(cs3500.threetrios.card.Card myCard, PlayerModel myPlayer) {
    this.myCard = myCard;
    this.myPlayer = myPlayer;
  }

  @Override
  public boolean canPlayCard() {
    return myPlayer == null;
  }

  @Override
  public void switchPlayer(cs3500.threetrios.provider.model.Player player) {
    if (player == null) {
      throw new IllegalArgumentException("Player cannot be null");
    }
    this.myPlayer = PlayerAdapter.toPlayerModel(player);
  }


  @Override
  public boolean battle(Slot other, Direction direction) {
    if (other == null || direction == null) {
      throw new IllegalArgumentException("Other slot or direction cannot be null");
    }

    AttackValue thisAttack = getAttackValue(direction);
    AttackValue otherDefense = other.getDirectionalValues()
            .get(direction.getOppositeDirection());

    return thisAttack.compareToValue(otherDefense) > 0;
  }


  @Override
  public void addToPlayerCount(Map<Player, Integer> curCount) {
    if (myPlayer != null) {
      Player adaptedPlayer =
              PlayerAdapter.toProviderPlayer(myPlayer);

      curCount.put(adaptedPlayer, curCount.getOrDefault(adaptedPlayer, 0) + 1);
    }
  }


  @Override
  public int compareAttackValueTo(Direction dirAttackComingFrom, AttackValue other) {
    if (dirAttackComingFrom == null || other == null) {
      throw new IllegalArgumentException("Direction and AttackValue cannot be null");
    }
    AttackValue thisValue = getAttackValue(dirAttackComingFrom);
    return thisValue.compareToValue(other);
  }


  @Override
  public String boardPrint() {
    return myCard.toString();
  }

  public Slot copySlot() {
    return new CardAdapter(new CardModel(myCard.getName(), myCard.getNorth(),
            myCard.getSouth(),
            myCard.getEast(),
            myCard.getWest(),
            myCard.getColor()), myPlayer);
  }

  @Override
  public Player getSlotOwner() {
    return PlayerAdapter.toProviderPlayer(myPlayer);
  }


  @Override
  public Color getSlotColor() {
    switch (myCard.getColor()) {
      case RED:
        return Color.RED;
      case BLUE:
        return Color.BLUE;
      default:
        throw new IllegalArgumentException("Unsupported color");
    }
  }


  @Override
  public Map<Direction, AttackValue> getDirectionalValues() {
    return Map.of(
            Direction.UP, mapToAttackValue(myCard.getNorth()),
            Direction.DOWN, mapToAttackValue(myCard.getSouth()),
            Direction.LEFT, mapToAttackValue(myCard.getWest()),
            Direction.RIGHT, mapToAttackValue(myCard.getEast())
    );
  }

  private AttackValue mapToAttackValue(int value) {
    switch (value) {
      case 1: return AttackValue.ONE;
      case 2: return AttackValue.TWO;
      case 3: return AttackValue.THREE;
      case 4: return AttackValue.FOUR;
      case 5: return AttackValue.FIVE;
      case 6: return AttackValue.SIX;
      case 7: return AttackValue.SEVEN;
      case 8: return AttackValue.EIGHT;
      case 9: return AttackValue.NINE;
      case 10: return AttackValue.A;
      default:
        throw new IllegalArgumentException("Invalid attack value: " + value);
    }
  }

  /**
   * Helper method to get the attack value for a given direction.
   */
  private AttackValue getAttackValue(Direction direction) {
    switch (direction) {
      case UP:
        return mapToAttackValue(myCard.getNorth());
      case DOWN:
        return mapToAttackValue(myCard.getSouth());
      case LEFT:
        return mapToAttackValue(myCard.getWest());
      case RIGHT:
        return mapToAttackValue(myCard.getEast());
      default:
        throw new IllegalArgumentException("Invalid direction: " + direction);
    }
  }
}

