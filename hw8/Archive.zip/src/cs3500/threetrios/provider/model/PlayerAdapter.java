package cs3500.threetrios.provider.model;

import java.util.ArrayList;

import cs3500.threetrios.card.COLOR;
import cs3500.threetrios.player.PlayerModel;

public class PlayerAdapter {
  public static Player toProviderPlayer(PlayerModel player) {
    return cs3500.threetrios.provider.model.Player.valueOf(player.getName().toUpperCase());
  }

  public static PlayerModel toPlayerModel(cs3500.threetrios.provider.model.Player providerPlayer) {
    COLOR color = providerPlayer == Player.A ? COLOR.RED : COLOR.BLUE;
    return new PlayerModel(providerPlayer.name(), color, new ArrayList<>());
  }
}

