package cs3500.tictactoe;
import javax.swing.*;

/**
 * This is the gui version of the view.
 */
public class TicTacToeView extends JFrame implements TTTView {

  private final TTTPanel panel;

  /**
   * This is the constructor for the class.
   */
  public TicTacToeView() {
    this.panel = new TTTPanel();
    this.setSize(600, 600);
    this.setLocationRelativeTo(null);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.add(this.panel);
  }
  @Override
  public void addClickListener(TicTacToeController listener) {
    this.panel.addClickListener(new TTTClickListener());
  }

  @Override
  public void refresh() {
    this.repaint();
  }

  @Override
  public void makeVisible() {
    this.setVisible(true);
  }
}
