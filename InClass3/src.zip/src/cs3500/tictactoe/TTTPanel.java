package cs3500.tictactoe;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * This is the panel, uses the mouse variables.
 */
public class TTTPanel extends JPanel {

  private TicTacToeController features;

    /**
     * This is the constructor for the class.
     */
  public TTTPanel() {
    this.addMouseListener(new TTTClickListener());
  }

  /**
   * This is a clicker button.
   * @param features incoorporates the TicTacToeController
   */
  public void addClickListener(TicTacToeController features) {
    this.features = features;
    this.addMouseListener(new TTTClickListener());
  }

  private class TTTClickListener implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent e) {
      System.err.println(e.getX() + " " + e.getY());
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    /**
     * Invoked when a mouse button has been released on a component.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseReleased(MouseEvent e) {

    }

    /**
     * Invoked when the mouse enters a component.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseEntered(MouseEvent e) {

    }

    /**
     * Invoked when the mouse exits a component.
     *
     * @param e the event to be processed
     */
    @Override
    public void mouseExited(MouseEvent e) {

    }
  }
}
