


Changes
SoloRedModel - took out the checker for if  game started on drawHands((