package cs3500.threetrios;

import cs3500.threetrios.Game.Game;
import cs3500.threetrios.Game.GameGrid;
import cs3500.threetrios.Game.GameModel;
import cs3500.threetrios.Game.Grid;

public class Main {
  public static void main(String[] args) {
    Grid grid = new GameGrid(3, 3);

    Game game = new GameModel(grid);

//    GameController controller = new GameController(game);



  }

}
