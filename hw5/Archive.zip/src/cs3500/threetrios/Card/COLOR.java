package cs3500.threetrios.Card;

/**
 * Class ENUM to represent each player.
 */
public enum COLOR {
  RED, BLUE
}
